# প্রবাস: স্বপ্নের ওপারে অন্ধকার — Flipbook Website

এই ফোল্ডারে তৈরি করা হয়েছে একটি static website:
- `index.html` — কভার পেজ ও flipbook reader
- `book.pdf` — আপনার ২৬ পৃষ্ঠার PDF
- `cover.jpg` — PDF-এর প্রথম পৃষ্ঠা থেকে তৈরি preview image
- `vercel.json` — Vercel static deployment config

## Vercel-এ প্রকাশ করার সহজ পদ্ধতি (ফোন থেকেও করা যায়)

1. ZIP ফাইলটি extract করুন।
2. https://vercel.com/ এ সাইন আপ/লগইন করুন।
3. GitHub-এ নতুন repository তৈরি করে এই ফোল্ডারের চারটি ফাইল আপলোড করুন।
4. Vercel Dashboard → Add New → Project → ওই GitHub repository Import করুন।
5. Framework Preset: `Other`; Build Command ফাঁকা রাখুন; Output Directory `.` দিন (অথবা ডিফল্ট static output রাখুন)।
6. Deploy চাপুন। Vercel একটি `*.vercel.app` URL দেবে।
7. সেই URL-এ সাইট খুলে “বই পড়ুন” চাপুন। সব ঠিক থাকলে PDF থেকে পৃষ্ঠা তৈরি হয়ে flipbook দেখাবে।

## WhatsApp/Facebook/Messenger-এ কভার preview
`index.html`-এর এই লাইনটি খুঁজুন:
`<meta property="og:image" content="https://YOUR-DOMAIN-HERE/cover.jpg">`
Deploy হওয়ার পর social preview cache update করার জন্য দরকার হলে `og:image`-এ সম্পূর্ণ URL বসান, যেমন:
`https://your-project.vercel.app/cover.jpg`
তারপর GitHub-এ পরিবর্তন commit করুন; Vercel আবার deploy করবে। সামাজিক অ্যাপের preview আপডেট হতে কিছু সময় লাগতে পারে এবং সব অ্যাপ একইভাবে preview দেখায় না।

## গুরুত্বপূর্ণ
- সাইটটি public: URL জানা যে কেউ বইটি পড়তে এবং `book.pdf` ফাইলটি সরাসরি খুলতে পারবে।
- পৃষ্ঠা render করতে PDF.js এবং flip effect-এর জন্য PageFlip CDN ব্যবহার করা হয়েছে; প্রথমবার পড়ার সময় internet connection প্রয়োজন।
- PDF-এর প্রথম পৃষ্ঠাটি কভার হিসেবে দেখানো হবে। PDF-এ কভার পৃষ্ঠা না থাকলে আগে PDF-এ কভার যোগ করে নিন।
